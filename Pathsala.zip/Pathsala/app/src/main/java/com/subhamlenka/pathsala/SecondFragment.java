package com.subhamlenka.pathsala;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.subhamlenka.pathsala.R;


public class SecondFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        return inflater.inflate(R.layout.fragment_second, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        WebView view1 = (WebView) view.findViewById(R.id.webb);
        String dataa = "https://stackoverflow.com/";




        view1.getSettings().setJavaScriptEnabled(true);
        view1.getSettings().setPluginState(WebSettings.PluginState.ON);
//        view.loadUrl("http://google.com");
        view1.loadUrl(dataa);
        view1.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view1, WebResourceRequest request) {
                view1.loadUrl(request.toString());
                return true;
            }
        });

        getActivity().setTitle("Menu 1");
    }
}